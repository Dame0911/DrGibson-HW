package prob;

public class Wolf extends Animal{
	public Wolf(String name, double weight) {
		super(name,weight);
	}
	
	public String makeSound() {
		return "HWOOOOO";
	}
	public String toString() {
		return "";
	}

}
