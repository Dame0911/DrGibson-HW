package prob;

public class SuperAccount extends Account {
	private double assets;
	
	public SuperAccount(String name, double balance, double assets) {
		super(name,balance);
		this.assets = assets;
	}
	
	public SuperAccount(String name, double balance) {
		this(name,balance,0);
		}
	
	public double getAssets() {
		return assets + balance;
	}
	
	@Override
	public String toString() {
		String msg  =   "";
		return  msg;
	}
	

}
