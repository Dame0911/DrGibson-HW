package prob;

public class Horse extends Animal {
	
	public Horse(String name, double weight) {
		super(name,weight);
	}
	
	public String makeSound() {
		return "NAAAAAYYYY";
	}
	
	public String toString() {
		return "";
	}

}
