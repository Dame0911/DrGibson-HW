package prob;

public class Account {
	protected String name;
	protected double balance;
	
	public Account(String name, double balance) {
		this.name = name;
		this.balance = balance;
	}
	
	public String getName() {
		return name;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public String toString() {
		String msg = "";
		return msg;
	}
	
	 public static void main(String[]args) {
//		Account a  = new Account("Damian",400);
//		SuperAccount ma = new SuperAccount("Damari",700,10000);
//		
//		System.out.println(ma.getAssets());
//		System.out.println(a.getBalance());
		 
		 Horse h = new Horse("Gary",400);
		 Elephant e = new Elephant("George",2000);
		 Wolf w = new Wolf("Alex",120);
		 
		 Jungle jun = new Jungle();
		 jun.add(h);
		 jun.add(w);
		 jun.add(e);
		 
		 System.out.println(jun.makeSounds());
		 
		 
//		 System.out.println(h.name + " is the name of my horse");
//		 System.out.println(e.name + " is the name of my elephant");
//		 System.out.println(w.name + " is the name of my wolf");
//		 
		
	}
	
	
	

}
