package prob;

public class Elephant extends Animal{
	public Elephant(String name, double weight) {
		super(name,weight);	
	}
	
	public String makeSound() {
		return "HOOOORNNN";
	}
	
	public String toString() {
		return "";
	}

}
