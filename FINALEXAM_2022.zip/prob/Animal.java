package prob;

public abstract class Animal {
	protected String name;
	protected double weight;
	
	public Animal(String name, double weight) {
		this.name = name;
		this.weight = weight;
	}
	
	public String getName() {
		return name;
	}
	
	public double getWeight() {
		return weight;
	}
	public abstract String makeSound();
	
	public String toString() {
		return "";	
	}

}
