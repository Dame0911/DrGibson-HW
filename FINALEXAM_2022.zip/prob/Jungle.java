package prob;
import java.util.ArrayList;

public class Jungle {
	protected ArrayList<Animal> jungles= new ArrayList<>();
	protected int size;
	
	public Jungle() {	
	}
	
	public void add(Animal a) {
		jungles.add(a);
	}
	
	public String makeSounds() {
		String msg = "";
		for(int i = 0; i < jungles.size(); i ++) {
			msg += jungles.get(i).getName() + " says " + jungles.get(i).makeSound() + "  ";
		}
		return msg;
	}
	
	public String toString() {
		return "";
	}
	
	
	

}
