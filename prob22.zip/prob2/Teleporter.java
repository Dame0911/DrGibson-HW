package prob2;

public interface Teleporter {

}
