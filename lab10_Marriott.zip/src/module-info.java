/**
 * 
 */
/**
 * @author media_help
 *
 */
module lab10_Marriott {
}