package prob2;

public abstract class Martian extends Object implements Comparable<Martian>{
	protected int id;
	protected int volume;
	
	public Martian(int id, int volume) {
		this.id = id;
		this.volume = volume;
	}
	
	public int compareTo(Martian m) {
	if(this.id == m.id) {
		return 0;
	}
	else if(this.id > m.id) {
		return 1;
	}
	else{
		return -1;
	}

	}
	
	public boolean equals(Object m) {
		if(m instanceof Martian) {
			Martian ma = (Martian)m;
			if(this.id == ma.id) {
				return true;
			}
		}return false;
	}
	
	public int getId() {
		return id;
	}
	
	public int getVolume() {
		return volume;
	}
	
	public void setVolume(int v) {
		this.id = v;
	}
	
	public abstract String speak();
	
	
	

}
