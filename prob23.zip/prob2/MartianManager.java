package prob2;

public class MartianManager {

}
