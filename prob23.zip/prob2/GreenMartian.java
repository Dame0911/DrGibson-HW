package prob2;

public class GreenMartian extends Martian implements Teleporter { //Completed
	
	public GreenMartian(int id, int v) {
		super(id,v);
	}
	
	public GreenMartian(int id) {
		this(id,1);
	}
	
	public String speak() {
		return "id=" + getId() + ", Grobly Grock";
	}
	
	public String teleporter(String dest) {
		return "id=" +  getId() + ", teleporting to " + dest;
	}
	
	public String toString() {
		return "Green Martian- id:" + getId() + ", volume:" + getVolume();
	}
	

}
