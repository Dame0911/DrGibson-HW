package prob2;

public interface Teleporter {
	public String teleporter(String dest);
}
