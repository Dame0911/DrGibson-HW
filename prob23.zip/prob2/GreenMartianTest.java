package prob2;

public class GreenMartianTest {
	public static void main(String[]args) {
//		testSpeakAndTeleportAndToString();        //Completed
//		testEquals_Success();
//		testEquals_Fail();
		testEquals_redAndGreen_success_Negative();
		testCompareTo_redAndGreen_success();
		
	}
	
	public static void testSpeakAndTeleportAndToString(){
		System.out.println("-->testSpeakAndTeleportAndToSpeak()");
		GreenMartian green = new GreenMartian(1,1);
		green.teleporter("4th Quadrant");
		System.out.println("Expected: Speak: id=1, Grobly Grock");
		System.out.println("Teleport: id=1, teleporting to 4th Quadrant \nToString: Green Martian - id=xxx, vol=yyy");
		System.out.println("------------------------------------------>");
		System.out.println("Actual: Speak: " + green.speak() + "\nTeleport: "+ green.teleporter("4th Quadrant") + "\nToString: " + green);

		}
	public static void testEquals_Success() {
		System.out.println("--->testEquals_Success()");
		GreenMartian grud = new GreenMartian(1,1);
		GreenMartian gren = new GreenMartian(1,4);
		System.out.println("Expected: True");
		System.out.println("Actual: " + grud.equals(gren));
	}
	
	public static void testEquals_Fail() {
		System.out.println("--->testEquals_Fail()");
		GreenMartian grud = new GreenMartian(1,1);
		GreenMartian gren = new GreenMartian(2,4);
		System.out.println("Expected: False");
		System.out.println("Actual: " + grud.equals(gren));
	}
	
	public static void testEquals_redAndGreen_success_Negative() {
		System.out.println("--->testCompareTo_Negative()");
		RedMartian vrud = new RedMartian(1,1,1);
		RedMartian gren = new RedMartian(2,4);
		System.out.println("Expected: False");
		System.out.println("Actual : " + vrud.equals(gren));
		
	}
	public static void testCompareTo_redAndGreen_success() {
		System.out.println("--->testCompareTo_redAndGreen_success()");
		RedMartian vrud = new RedMartian(1,1,1);
		RedMartian gren = new RedMartian(1,4);
		System.out.println("Expected: True");
		System.out.println("Actual : " + vrud.equals(gren));
	}
	
	
	

}
