package prob2;

public class RedMartianTest {  //Complete
	
	public static void main(String[]args){
//	testSpeakAndToString();
//	testEquals_Success();
//	testEquals_Fail();
//	testCompareTo_Negative();
//	testCompareTo_Positive();
//	testCompareTo_Zero();
	
	}
	
	public static void testSpeakAndToString(){
		System.out.println("-->testSpeakAndToSpeak()");
		RedMartian red = new RedMartian(1,1,1);
		System.out.println("Expected: Speak: id: 1, Ruldy Rock \nToString: Martian - id=xxx, vol=yyy, ten=zzz");
		System.out.println("Actual: Speak: " + red.speak() + "\nToString: " + red);

		}
	public static void testEquals_Success() {
		System.out.println("--->testEquals_Success()");
		RedMartian vrud = new RedMartian(1,1,1);
		RedMartian vren = new RedMartian(1,4,5);
		System.out.println("Expected: True");
		System.out.println("Actual: " + vrud.equals(vren));
	}
	
	public static void testEquals_Fail() {
		System.out.println("--->testEquals_Fail()");
		RedMartian vrud = new RedMartian(1,1,1);
		RedMartian vren = new RedMartian(2,4,5);
		System.out.println("Expected: False");
		System.out.println("Actual: " + vrud.equals(vren));
		
	}
	
	public static void testCompareTo_Negative() {
		System.out.println("--->testCompareTo_Negative()");
		RedMartian vrud = new RedMartian(1,1,1);
		RedMartian vren = new RedMartian(2,4,5);
		System.out.println("Expected: -1");
		System.out.println("Actual: " + vrud.compareTo(vren));
		
	}
	public static void testCompareTo_Positive() {
		System.out.println("--->testCompareTo_Positive()");
		RedMartian vrud = new RedMartian(7,1,1);
		RedMartian vren = new RedMartian(2,4,5);
		System.out.println("Expected: 1");
		System.out.println("Actual: " + vrud.compareTo(vren));
		
	}
	
	public static void testCompareTo_Zero() {
		System.out.println("--->testCompareTo_Negative()");
		RedMartian vrud = new RedMartian(2,1,1);
		RedMartian vren = new RedMartian(2,4,5);
		System.out.println("Expected: 0");
		System.out.println("Actual: " + vrud.compareTo(vren));
		
	}
	
	
	
		

	}
		
