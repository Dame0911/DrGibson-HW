package prob2;

public class RedMartian extends Martian{  //Completed
	public int tenacity;
	
	public RedMartian(int id, int volume, int tenacity) {
		super(id,volume);
		this.tenacity = tenacity;
	}
	
	public RedMartian(int id, int tenacity) {
		this(id,1,tenacity);
	}
	
	public String speak() {
		return "id:" + getId() + ", Ruldy Rock";
	}
	
	public int getTenacity() {
		return tenacity;
	}
	
	@Override
	public String toString() {
		return "Red Martian- id:" + getId() + ", volume:" + getVolume() + ", tenacity:" + getTenacity();
		
	}

}
