package prob1;
import emps.Employee;

public class Store {
	private Employee[]emps = new Employee[20];
	private int numEmps;
	
	public Store() {
		numEmps = 0;
	}
	public int getNumEmployees(){
		return numEmps;
	}
	public void addEmployee(Employee e) {
		if(numEmps < emps.length) {
			emps[numEmps] = e;
			numEmps += 1;
		}
		
	}
	
	public Employee getEmployee(int i){
		if(i > numEmps || i < 0){
			return null;
		}
		else {
		return emps[i];
		}
	}
	
	public double getTotalHours(){
		double total =0;
		for(int i=0; i < numEmps; i++) {
			total += emps[i].getTotalHours();
			
		}
		return total;
	}
	public double getTotalPay() {
		double a = 0;
		
		for(int i=0; i < numEmps; i++) {
			a += emps[i].getPay();
		}
		return a;
	}
	public Employee removeEmployee(int i) {
		Employee a;
		if(i < 0 || i >= numEmps) {
			return null;
		}
		else {
			numEmps--;
			a = emps[i];
			return a;
		}
	}
	public Employee getEmployeeWithName(String findName) {
		Employee e = null; 
		for(int i = 0; i < emps.length; i++) {
			if(emps[i].getName().equals(findName)) { 
				return emps[i];
			}
		}
		return e;
		
	}
	
	public String toString() {
		String msg = "\nPayroll Report" + "\n" + "Num Employees:" + numEmps + ", total hrs:" + getTotalHours() +
				     ", total pay=$" + getTotalPay() + "\n" + "\nPay Stub" + "\n---------" + "\nName:" + emps[0].getName() + 
				     ", Pay Rate $" + emps[0].getPayRate() + ("\nMon:" + emps[0].getHours(0) + " Tue:" + emps[0].getHours(1) + 
				     " Wed:" + emps[0].getHours(2) + " Thu:" + emps[0].getHours(3) + " Fri:" + emps[0].getHours(4) + " Sat:" + 
				     emps[0].getHours(5) + " Sun:" + emps[0].getHours(6)) + "\nDays Worked:" + emps[0].getNumDaysWorked() +
				     ", Total Hours:" + emps[0].getTotalHours() + "\nWeekday hours:" + emps[0].getWeekdayHours() + ", Weekend hours:" + 
				     emps[0].getWeekendHours() + "\nTotal pay: $" + emps[0].getPay() + 
				     
				     "\nPay Stub" + "\n---------" + "\nName:" + emps[1].getName() + 
				     ", Pay Rate $" + emps[1].getPayRate() + ("\nMon:" + emps[1].getHours(0) + " Tue:" + emps[1].getHours(1) + 
				     " Wed:" + emps[1].getHours(2) + " Thu:" + emps[1].getHours(3) + " Fri:" + emps[1].getHours(4) + " Sat:" + 
				     emps[1].getHours(5) + " Sun:" + emps[1].getHours(6)) + "\nDays Worked:" + emps[1].getNumDaysWorked() +
				     ", Total Hours:" + emps[1].getTotalHours() + "\nWeekday hours:" + emps[1].getWeekdayHours() + ", Weekend hours:" + 
				     emps[1].getWeekendHours() + "\nTotal pay: $" + emps[1].getPay() +
				     
				     "\nPay Stub" + "\n---------" + "\nName:" + emps[2].getName() + 
				     ", Pay Rate $" + emps[2].getPayRate() + ("\nMon:" + emps[2].getHours(0) + " Tue:" + emps[2].getHours(1) + 
				     " Wed:" + emps[2].getHours(2) + " Thu:" + emps[2].getHours(3) + " Fri:" + emps[2].getHours(4) + " Sat:" + 
				     emps[2].getHours(5) + " Sun:" + emps[2].getHours(6)) + "\nDays Worked:" + emps[2].getNumDaysWorked() +
				     ", Total Hours:" + emps[2].getTotalHours() + "\nWeekday hours:" + emps[2].getWeekdayHours() + ", Weekend hours:" + 
				     emps[2].getWeekendHours() + "\nTotal pay: $" + emps[2].getPay();
		              
		
		
		
		
		
		return msg;
		
	}
		
		
	}
	
	
	

	

	
	
	

